package threads.exo.factories;

public class Carcasse {

    private String marque;

    public Carcasse(String marque) {
        this.marque = marque;
    }

    public String getMarque() {
        return marque;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

}
