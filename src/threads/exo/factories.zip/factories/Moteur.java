package threads.exo.factories;

public class Moteur {

    private String marque;

    public Moteur(String marque) {
        this.marque = marque;
    }

    public String getMarque() {
        return marque;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }
}
