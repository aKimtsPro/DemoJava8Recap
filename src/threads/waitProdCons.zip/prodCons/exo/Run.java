package threads.prodCons.exo;

public class Run {

    public static void main(String[] args) throws InterruptedException {

        Stock s = new Stock(5);

    }
}
