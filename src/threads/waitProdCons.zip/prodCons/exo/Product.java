package threads.prodCons.exo;

public class Product { }
